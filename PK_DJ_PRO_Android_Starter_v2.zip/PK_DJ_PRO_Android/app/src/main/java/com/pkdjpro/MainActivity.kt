package com.pkdjpro

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(9, 11, 16)
    private val panel = Color.rgb(22, 26, 35)
    private val red = Color.rgb(229, 57, 53)
    private lateinit var playerA: ExoPlayer
    private lateinit var playerB: ExoPlayer
    private lateinit var titleA: TextView
    private lateinit var titleB: TextView
    private lateinit var statusA: TextView
    private lateinit var statusB: TextView
    private lateinit var crossfader: SeekBar
    private lateinit var volumeA: SeekBar
    private lateinit var volumeB: SeekBar
    private lateinit var progressA: SeekBar
    private lateinit var progressB: SeekBar
    private val handler = Handler(Looper.getMainLooper())
    private var userSeekingA = false
    private var userSeekingB = false

    private val pickA = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { loadTrack(it, playerA, titleA, "A") }
    }
    private val pickB = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { loadTrack(it, playerB, titleB, "B") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        playerA = ExoPlayer.Builder(this).build()
        playerB = ExoPlayer.Builder(this).build()
        buildUi()
        applyMix()
        handler.post(updateProgress)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(14, 12, 14, 12)
        }
        val header = TextView(this).apply {
            text = "PK  DJ PRO   •   OFFLINE DECKS"
            textSize = 21f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(4, 12, 4, 16)
        }
        root.addView(header)
        val decks = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val deckA = makeDeck("DECK A", true)
        val deckB = makeDeck("DECK B", false)
        decks.addView(deckA, LinearLayout.LayoutParams(0, 0, 1f).apply { height = LinearLayout.LayoutParams.WRAP_CONTENT; width = 0; marginEnd = 6 })
        decks.addView(deckB, LinearLayout.LayoutParams(0, 0, 1f).apply { height = LinearLayout.LayoutParams.WRAP_CONTENT; width = 0; marginStart = 6 })
        root.addView(decks)
        root.addView(label("MASTER MIXER"))
        val crossRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        crossRow.addView(TextView(this).apply { text = "A"; setTextColor(Color.WHITE); textSize = 12f })
        crossRow.addView(label("CROSSFADER"), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        crossRow.addView(TextView(this).apply { text = "B"; setTextColor(Color.WHITE); textSize = 12f })
        root.addView(crossRow)
        crossfader = SeekBar(this).apply {
            max = 100; progress = 50
            setOnSeekBarChangeListener(simpleSeek { applyMix() })
        }
        root.addView(crossfader)
        root.addView(Button(this).apply {
            text = "CENTER CROSSFADER"
            setOnClickListener { crossfader.progress = 50; applyMix() }
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text = "A"; setTextColor(Color.WHITE) })
        volumeA = SeekBar(this).apply { max = 100; progress = 85; setOnSeekBarChangeListener(simpleSeek { applyMix() }) }
        row.addView(volumeA, LinearLayout.LayoutParams(0, 48, 1f))
        row.addView(TextView(this).apply { text = "B"; setTextColor(Color.WHITE) })
        volumeB = SeekBar(this).apply { max = 100; progress = 85; setOnSeekBarChangeListener(simpleSeek { applyMix() }) }
        row.addView(volumeB, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(row)
        root.addView(label("MUSIC LIBRARY SEARCH"))
        val searchBox = EditText(this).apply {
            hint = "Search loaded tracks by filename"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(34, 39, 50))
        }
        root.addView(searchBox)
        val searchInfo = TextView(this).apply {
            text = "Search matches tracks loaded into either deck."
            setTextColor(Color.LTGRAY); textSize = 12f; setPadding(8, 8, 8, 8)
        }
        root.addView(searchInfo)
        searchBox.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s?.toString()?.trim()?.lowercase(Locale.ROOT).orEmpty()
                val matches = listOf(titleA.text.toString(), titleB.text.toString())
                    .filter { it != "No track loaded" && it.lowercase(Locale.ROOT).contains(q) }
                searchInfo.text = when {
                    q.isEmpty() -> "Search matches tracks loaded into either deck."
                    matches.isEmpty() -> "No loaded track matches \"$q\". Load audio from your phone to add it."
                    else -> "Matches: " + matches.joinToString(" • ")
                }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        root.addView(label("QUICK NOTES"))
        root.addView(TextView(this).apply {
            text = "Offline search currently filters tracks loaded into Deck A or Deck B. Full phone-library indexing and advanced DJ tools are planned for later builds."
            setTextColor(Color.LTGRAY); textSize = 12f; setPadding(10, 8, 10, 8)
        })
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun makeDeck(name: String, isA: Boolean): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 12, 10, 12)
            setBackgroundColor(panel)
        }
        card.addView(TextView(this).apply {
            text = name; textSize = 18f; setTextColor(if (isA) Color.rgb(255, 100, 90) else Color.rgb(80, 190, 255))
            gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        val title = TextView(this).apply {
            text = "No track loaded"; textSize = 13f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; minLines = 2; setPadding(2, 10, 2, 8)
        }
        if (isA) titleA = title else titleB = title
        card.addView(title)
        val load = Button(this).apply {
            text = "LOAD TRACK"; setOnClickListener { if (isA) pickA.launch(arrayOf("audio/*")) else pickB.launch(arrayOf("audio/*")) }
        }
        card.addView(load)
        val status = TextView(this).apply {
            text = "00:00 / 00:00"; textSize = 11f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        if (isA) statusA = status else statusB = status
        card.addView(status)
        val progress = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val player = if (isA) playerA else playerB
                        if (player.duration > 0) player.seekTo((player.duration * p / 1000).toLong())
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) { if (isA) userSeekingA = true else userSeekingB = true }
                override fun onStopTrackingTouch(s: SeekBar?) { if (isA) userSeekingA = false else userSeekingB = false }
            })
        }
        if (isA) progressA = progress else progressB = progress
        card.addView(progress)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(Button(this).apply { text = "▶"; setOnClickListener { val p = if (isA) playerA else playerB; if (p.mediaItemCount > 0) p.play() } },
            LinearLayout.LayoutParams(0, 52, 1f))
        controls.addView(Button(this).apply { text = "Ⅱ"; setOnClickListener { (if (isA) playerA else playerB).pause() } },
            LinearLayout.LayoutParams(0, 52, 1f))
        controls.addView(Button(this).apply { text = "STOP"; setOnClickListener { val p = if (isA) playerA else playerB; p.pause(); p.seekTo(0) } },
            LinearLayout.LayoutParams(0, 52, 1f))
        card.addView(controls)
        return card
    }

    private fun loadTrack(uri: Uri, player: ExoPlayer, title: TextView, deck: String) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        player.pause()
        val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected audio"
        title.text = name
        Toast.makeText(this, "Track loaded on Deck $deck", Toast.LENGTH_SHORT).show()
    }

    private fun label(value: String) = TextView(this).apply {
        text = value; setTextColor(Color.WHITE); textSize = 13f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(4, 14, 4, 4)
    }

    private fun simpleSeek(action: () -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) action() }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun applyMix() {
        if (!::crossfader.isInitialized) return
        val x = crossfader.progress / 100f
        val a = (volumeA.progress / 100f) * (1f - x).coerceAtMost(1f)
        val b = (volumeB.progress / 100f) * x.coerceAtMost(1f)
        playerA.volume = a
        playerB.volume = b
    }

    private val updateProgress = object : Runnable {
        override fun run() {
            updateOne(playerA, progressA, statusA, userSeekingA)
            updateOne(playerB, progressB, statusB, userSeekingB)
            handler.postDelayed(this, 400)
        }
    }

    private fun updateOne(p: ExoPlayer, bar: SeekBar, label: TextView, seeking: Boolean) {
        val duration = p.duration
        if (duration > 0 && duration != androidx.media3.common.C.TIME_UNSET) {
            if (!seeking) bar.progress = ((p.currentPosition.toDouble() / duration) * 1000).toInt().coerceIn(0, 1000)
            label.text = "${time(p.currentPosition)} / ${time(duration)}"
        }
    }
    private fun time(ms: Long): String {
        val seconds = (ms / 1000).coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    }

    override fun onDestroy() {
        handler.removeCallbacks(updateProgress)
        playerA.release(); playerB.release()
        super.onDestroy()
    }
}
